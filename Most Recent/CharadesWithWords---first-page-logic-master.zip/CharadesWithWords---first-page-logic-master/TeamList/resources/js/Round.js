// remove event listener from ready button and change innerHTML to start Game
// page loads with: what Team is playing
//                  whose turn it is
//                  what catagory is coming up
//

function roundPrep(team) {
  // readyBtn.addEventListener('click', roundBegin);
  // var heading = document.createElement('h1');
  // var body = `<p>${team.name}, it's your round.</p>
  //             <p>${team.players[team.whoseGo]} you're describing.</p>`;
  //
  alert(team.name);
}
