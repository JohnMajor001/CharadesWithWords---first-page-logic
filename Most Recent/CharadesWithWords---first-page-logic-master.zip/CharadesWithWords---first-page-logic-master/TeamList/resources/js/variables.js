var noOfTeams = 0;
var noOfPlayers = 0;
var addItemBtn = document.getElementById('addItemBtn');
var list = document.getElementById('list');
var readyBtn = document.getElementById('readyBtn');
var teamNamesArray = [];
var playerNamesArray = [];
var teamObjectsArray = [];


/*function team(playerNames, numberOfPlayers, score, position) {
  this.playerNames = playerNames;
  this.numberOfPlayers = numberOfPlayers;
  this.score = score;
  this.position = position;
}*/



// Things to do!
/* Make Team Name Box bigger
      Put 'X' at side of each third player box to deleteBtn
      do the same for team actually*/

// Organise arrays of player Names in accordance with relevant Team Names
